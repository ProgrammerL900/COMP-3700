CREATE TABLE "Customers" (
"CustomerID" INTEGER NOT NULL,
"Name" TEXT DEFAULT 'Laura Wilson',
"Phone" TEXT DEFAULT '902-847-1009',
"Address" TEXT DEFAULT 'Auburn',
"Paymentinfo" TEXT DEFAULT 123, 
PRIMARY KEY("CustomerID")
);

CREATE TABLE "Purchase" (
"purchaseid" INTEGER NOT NULL,
"customerid" INTEGER NOT NULL,
"productid" INTEGER NOT NULL,
"date time" TEXT DEFAULT '9/10/2023',
"quantity" INTEGER DEFAULT 3,
"price" REAL DEFAULT 100,
"tax" REAL DEFAULT 7,
PRIMARY KEY("purchaseid","customerid","productid")
);

CREATE TABLE "Products" (
"productid" INTEGER NOT NULL,
"barcode" TEXT DEFAULT 123,
"name" TEXT DEFAULT 'Laura Wilson',
"expiration date" TEXT DEFAULT '9/10/2020',
"price" REAL DEFAULT 100,
"tax rate" REAL DEFAULT '2%',
"quantity" REAL DEFAULT 1,
"supplier" TEXT DEFAULT 'Tobby',
"manufactured date" TEXT DEFAULT '9/10/2019',
PRIMARY KEY("productid")
);

INSERT INTO "main"."Customers" ("CustomerID", "Name", "Phone", "Address", "Paymentinfo") 
VALUES ('3', 'Laura Wilson', '857-225-3703', 'Auburn', 'Credit');
                    ('4', 'Tony Brown', '111-111-1111', 'New York', 'Cash');
 ('5', 'Phil Smith', '222-333-4444', 'Boston', 'Credit');
 ('6', 'Taylor Swift', '333-777-5555', 'Philadelphia', 'Paypal');
('7', 'Lilly Taylor', '111-222-3333', 'Birmingham', 'Credit');

INSERT INTO "main"."Products" ("productid", "barcode", "name", "expiration date", "price", "tax rate") VALUES ('1', '123', 'Potato', '9/29/2019', '10.0', '2%');
 ('4', '678', 'Tomato', '9/28/2019', '10.0', '2%');
 ('5', '789', 'Steak', '9/23/2019', '30.0', '2%');
 ('2', '234', 'Milk', '9/19/2019', '10.0', '2%');
('3', '456', 'Egg', '10/10/2019', '10.0', '2%');
	
INSERT INTO "main"."Purchase" ("purchaseid", "customerid", "productid", "date time", "quantity", "price", "tax")
 VALUES ('11', '3', '1', '9/10/2019', '3', '30.0', '0.6');
('12', '4', '4', '9/10/2019', '3', '30.0', '0.6');
('18', '5', '5', '9/10/2019', '2', '60.0', '1.2');
                ('22', '6', '2', '9/10/2019', '1', '10.0', '0.2');
                ('32', '7', '3', '9/10/2019', '5', '50.0', '1.0');
                ('39', '0', '1', '9/10/2019', '10', '100.0', '2.0');
                ('53', '0', '3', '9/10/2019', '10', '100.0', '2.0');
('69', '0', '4', '9/10/2019', '3', '30.0', '0.6');
('72', '0', '5', '9/10/2019', '3', '90.0', '1.8');
                ('90', '0', '2', '9/10/2019', '10', '100.0', '7.0');

