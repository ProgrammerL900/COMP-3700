import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class WebServer {

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8500), 0);
        HttpContext root = server.createContext("/");
        root.setHandler(WebServer::handleRequest);

        HttpContext context = server.createContext("/author");
        context.setHandler(WebServer::handleRequestAuthor);

        HttpContext product = server.createContext("/products");
        product.setHandler(WebServer::handleRequestProduct);


        server.start();
    }

    private static void handleRequest(HttpExchange exchange) throws IOException {
        String response = "Hi there! I am a simple web server!";
        exchange.sendResponseHeaders(200, response.getBytes().length);//response code and length
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }

    private static void handleRequestAuthor(HttpExchange exchange) throws IOException {
        String response = "Hi there! I am a simple web server!";



        exchange.sendResponseHeaders(200, response.getBytes().length);//response code and length
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }


    public class HtmlTableGenerator {

        public static String generateHtmlTable(ArrayList<String[]> data) {
            StringBuilder htmlTable = new StringBuilder();
            htmlTable.append("<table>\n");

            // Generate table headers
            String[] headers = data.get(0);
            htmlTable.append("<tr>\n");
            for (String header : headers) {
                htmlTable.append("<th>").append(header).append("</th>\n");
            }
            htmlTable.append("</tr>\n");

            // Generate table rows
            for (int i = 1; i < data.size(); i++) {
                String[] row = data.get(i);
                htmlTable.append("<tr>\n");
                for (String cell : row) {
                    htmlTable.append("<td>").append(cell).append("</td>\n");
                }
                htmlTable.append("</tr>\n");
            }

            htmlTable.append("</table>\n");
            return htmlTable.toString();
        }

        public static void main(String[] args) {
            // Sample data
            ArrayList<String[]> data = new ArrayList<>();
            data.add(new String[] {"Name", "Age", "Gender"});
            data.add(new String[] {"John", "25", "Male"});
            data.add(new String[] {"Jane", "30", "Female"});

            String htmlTable = generateHtmlTable(data);
            System.out.println(htmlTable);
        }
    }


    private static void handleRequestProduct(HttpExchange exchange) throws IOException {
//        String response =  "This simple web server is designed with help from ChatGPT!";

        String url = "jdbc:sqlite:store.db";

        SQLiteDataAdapter dao = new SQLiteDataAdapter();

        dao.connect(url);

        List<ProductModel> list = dao.loadAllProducts();

        String response = "<!DOCTYPE html>\n"
                + "<html>\n"
                + "  <head>\n"
                + "    <title>My Simple HTML Document</title>\n"
                + "  </head>\n"
                + "  <body>\n"
                + "    <h1>Hello World!</h1>\n"
                + "    <p>This is a simple HTML document.</p>\n"
                + " The server time is " + LocalDateTime.now()
                + " The data server has " + list.size() + " products"
                + "  </body>\n"
                + "</html>";


        exchange.sendResponseHeaders(200, response.getBytes().length);//response code and length
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}
